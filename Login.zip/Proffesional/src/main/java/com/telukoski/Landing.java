package com.telukoski;
import java.math.BigInteger;
import java.nio.channels.SelectableChannel;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;

import com.mysql.cj.protocol.Resultset;
class CodeWord{
	private static int otp;

	public static int getOtp() {
		return otp;
	}

	public static void setOtp(int otp) {
		CodeWord.otp = otp;
	}
}
public class Landing {
	
	

	public static int otp;
	
static String email;
static String password;
static String fname;
static String uname;
static String dob;
static String userid;
static String bio = "Conversation Makes Persons better"; 
public static Connection con;
public Landing(String email, String password, String fname, String uname, String dob) throws SQLException, ClassNotFoundException, NoSuchAlgorithmException {
	this.email=email;
	this.password=password;
	this.fname=fname;
	this.uname=uname;
	this.dob=dob;
	System.out.println(""+email+""+password+""+fname+""+uname+""+dob);
	Class.forName("com.mysql.cj.jdbc.Driver");
	con= DriverManager.getConnection("jdbc:mysql://localhost:3306/Chatters","root","");
     this.userid=userId();
      CodeWord.setOtp(otp());
      this.otp =CodeWord.getOtp();
      Mail obj = new Mail();
		System.out.println(Landing.email+" "+Landing.otp);
		obj.sendMail(Landing.email, Landing.otp);
    
     
}
public static String hashPassword(String password) throws NoSuchAlgorithmException{
	String salt="qwertyuiopoigfdsacvbnm,237890!@#$%^&*QWERTYUIKJHGFDSCVHJITRESXCVBL:";
    MessageDigest md = MessageDigest.getInstance("MD5");
    byte[] messageDigest = md.digest((password+salt).getBytes());
    StringBuilder builder=new StringBuilder(new BigInteger(1, messageDigest).toString(16));
    return builder.reverse().toString();
}
public String userId() {
	 Random random = new Random() ;
     String str = "abcdefghijklmnopqrstuvwxyzABCDEGFGHIJKLMNOPQRSTUVWXYZ0123456789";	
     String userid = "";
     for(int i=0;i<20;i++) {
    	 userid+=str.charAt(random.nextInt(61)+ 0);
     }
     return userid;
}
public static Connection getCon() throws ClassNotFoundException, SQLException {
	Class.forName("com.mysql.cj.jdbc.Driver");
	return DriverManager.getConnection("jdbc:mysql://localhost:3306/Chatters","root","");
}
public int otp(){
	 Random random = new Random() ;
     return random.nextInt(100000)+999999;
}
public static boolean signinCheck(String email, String password) throws SQLException, NoSuchAlgorithmException, ClassNotFoundException {
	System.out.println("ulla");
	if(con==null) {
		con=getCon();
	}
	PreparedStatement stmt = con.prepareStatement("select username_ghzy from users where email_xyq=? and password_ctf=?");
	stmt.setString(1, email);
	stmt.setString(2, hashPassword(password));
	System.out.println(stmt);
	ResultSet rs = stmt.executeQuery();
    return rs.next();
}
}
