package com.telukoski;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;

/**
 * Servlet implementation class Signin
 */
//@WebServlet("/Signin")
public class Signin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email =request.getParameter("email");
		String password = request.getParameter("pass");
		try {
			if(Landing.signinCheck(email,password)) {
				Cookie ck = new Cookie("cookey","true");
			    ck.setMaxAge(24*60*60); 
			    System.out.println(ck);
			    response.addCookie(ck);
				response.sendRedirect("welcome.jsp");
						}
		} catch (NoSuchAlgorithmException | SQLException e) {
			System.out.println("exce");
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
