package com.telukoski;

import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sound.midi.Soundbank;

import org.apache.catalina.ha.backend.Sender;

import jakarta.servlet.http.Cookie;

public class login {
	boolean loginuser(Connection con) throws SQLException, NoSuchAlgorithmException {
		PreparedStatement stmt ;
		stmt = con.prepareStatement("insert into users values(?,?,?,?,?,?,?)");
		stmt.setString(1,Landing.userid);
		stmt.setString(2,Landing.uname);
		stmt.setString(3,Landing.email);
		stmt.setString(4,Landing.dob);
		stmt.setString(5,Landing.fname);
		stmt.setString(6, Landing.bio);
		stmt.setString(7, Landing.hashPassword(Landing.password));
		System.out.println(Landing.uname);
		int i = 0;
		i=stmt.executeUpdate();
		if(i==1) {
			System.out.println("true");
			return true;
		}
		else {
		return false;
		}
	}



}
